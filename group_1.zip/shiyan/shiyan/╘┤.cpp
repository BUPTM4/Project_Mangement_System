#include<iostream>

using namespace std;

int main()
{
	int a = 25;
	int b = 5;
	int z=10;

	a = b = z;
	cout << a << b << z << endl;

	a = (b = z);
	cout << a << b << z << endl;
	return 0;

}
