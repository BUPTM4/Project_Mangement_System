#include "widget.h"
#include "ui_widget.h"
#include<QHostAddress>
#include<QFileDialog>
#include<QFileInfo>
#include<QDataStream>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("客户端");
    ui->textBrowser->append("请发送组别信息（example：group_1）：");
    timer =new QTimer(this);

    ui->progressBar->setValue(0);
    my_client=new QTcpSocket();
    conState=false;
    connect(this,&Widget::sendFileToYes,this,&Widget::sendtxtSLot);

}

Widget::~Widget()
{
    delete ui;
}



void Widget::on_btn_listen_clicked()
{
    QString address=ui->lineEdit_address->text();
    qint16 port=ui->lineEdit_port->text().toInt();
    QHostAddress ip=QHostAddress(address);
    if(!conState)
    {
        my_client->connectToHost(ip,port);
        if(!my_client->waitForConnected(5000))
        {
            QMessageBox::critical(this,"错误",my_client->errorString());
            return ;
        }
        else
        {
            ui->btn_listen->setText("断开连接");
            connect(my_client,&QTcpSocket::readyRead,this,&Widget::readyReadClientSlot);
            conState=true;
        }
    }
    else
    {
        conState=false;
        my_client->close();
        qDebug()<<"断开连接"<<endl;
        ui->btn_listen->setText("开始连接");
    }
}

void Widget::on_btn_send_clicked()
{
    QString str=ui->textEdit->toPlainText();
    QString res;
    res=str;
    QByteArray arr;
    QDataStream data(&arr,QIODevice::WriteOnly);
    MSG type=messAge;
    data<<type<<res.toLocal8Bit();
    my_client->write(arr);
    ui->textBrowser->append(res);
    ui->textEdit->clear();
    ui->textEdit->setFocus();
}

void Widget::readyReadClientSlot()
{
    int len=my_client->bytesAvailable();
    QByteArray arr=my_client->read(len>65536?65536:len);
    QString res=QString::fromLocal8Bit(arr);
    ui->textBrowser->append(res);
}

void Widget::on_btn_openfile_clicked()
{
    QString path=QFileDialog::getOpenFileName(this,"选择文件","E:/");
    ui->lineEdit_path->setText(path);

}

void Widget::on_btn_sendfile_clicked()
{
    if(!conState)//如果没有连接客户端弹出警告
    {
        QMessageBox::warning(this,"错误","没有连接服务端");
        return;
    }
    QString path=ui->lineEdit_path->text();//得到文件路径
    QFileInfo info(path);
    //获取文件信息
    filename=info.fileName();
    filesize=info.size();
    sendsize=0;//初始化发送的文件大小为0
    QByteArray arr;
    MSG type=fiLe;//发送的内容为文件类型
    QDataStream stream(&arr,QIODevice::WriteOnly);
    stream<<type<<filename<<filesize;//写入文件名和文件大小
    qDebug()<<filename<<" "<<filesize<<endl;
    //打开文件
    file.setFileName(path);
    file.open(QIODevice::ReadOnly);

    //ui->progressBar->setMaximum(filesize);
    my_client->write(arr);//发送内容到服务端
    connect(my_client, &QTcpSocket::bytesWritten, this, &Widget::sendtxtSLot);
    //resarr=arr;
    //emit this->sendFileToYes();//发送完后 发送已经发完文件信息的信号
}

void Widget::sendtxtSLot()
{
    //timer->start(5000);
    qDebug()<<"准备开始发送文件"<<endl;
    qDebug()<<"文件信息:"<<filename<<filesize<<endl<<"已经发送的大小："<<sendsize<<endl;
    if(sendsize<filesize)//当发送大小小于文件大小执行 文件比较小就换成了if 一次能读完 换成while现在还有bug
    {
        //connect(timer,&QTimer::timeout,this,&Widget::sendfiletxt);

        qDebug()<<"开始发送文件"<<endl;
        QByteArray arr=file.read(1024*10);//一次读取的内容
        QByteArray arrsend;
        QDataStream data(&arrsend,QIODevice::WriteOnly);
        MSG type=fiLe;//发送的内容为文件类型
        data<<type<<arr;//读入文件类型和文件内容
        my_client->write(arrsend);//发送数据内容
        sendsize+=arr.size();
        QString strfile=QString::fromUtf8(arr);
        ui->textBrowser->append(strfile);
        qDebug()<<"更新发送的大小"<<sendsize<<endl;
        ui->progressBar->setValue(sendsize);

    }
    if(filesize==sendsize)
    {
        qDebug()<<"文件发送完成"<<endl;
        file.close();
        filesize=0;
        sendsize=0;
        //timer->stop();
       // disconnect(timer,&QTimer::timeout,this,&Widget::sendfiletxt);
        disconnect(my_client, &QTcpSocket::bytesWritten, this, &Widget::sendtxtSLot);
    }

}

void Widget::on_pushButton_released()
{
    ui->stackedWidget->setCurrentWidget(ui->page);
}
