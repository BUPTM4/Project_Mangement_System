#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QTcpSocket>
#include<QDebug>
#include<QMessageBox>
#include<QFile>
#include<QTimer>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
    enum MSG{
        messAge,
        fiLe
    };
public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
private:

signals:
    void sendFileToYes();//测试bug用的信号，已经废弃
private slots:
    void on_btn_listen_clicked();//开始/断开连接

    void on_btn_send_clicked();//发送文本消息
    void readyReadClientSlot();//接收服务端文本消息

    void on_btn_openfile_clicked();//浏览文件

    void on_btn_sendfile_clicked();//发送文件，首先发送文件信息过去
    void sendtxtSLot();//发送文件内容

    void on_pushButton_released();

private:
    Ui::Widget *ui;
    QTcpSocket *my_client;
    bool conState;

    //文件
    QString filename;
    int filesize;
    int sendsize;
    QFile file;
    QByteArray resarr;
    QTimer *timer;//测试bug用，已舍弃
};

#endif // WIDGET_H
