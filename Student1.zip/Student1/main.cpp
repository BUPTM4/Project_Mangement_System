#include"Management.h"
#include"Window.h"
#include<easyx.h>
int main()
{
	Window w(960,640,EX_SHOWCONSOLE);
	w.setWindowTitle(" ��Ŀ����ϵͳ ");
	Management m;
	m.run();
	return w.exec();
}