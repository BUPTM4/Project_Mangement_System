#include "Management.h"
#include <iostream>
#include "Window.h"
using namespace std;

int Management::menu()
{
	cout << "menu" << endl;
	int op = 0;
	cin >> op;
	return op;
}

void Management::run()
{
    // ��ȡ�˵�����ֵ
    int op = Menu;
    while (true)
    {
        if (Window::hasMsg())
        {
            m_msg = Window::getMsg();
            switch (m_msg.message)
            {
            case WM_KEYDOWN:
                // ��������
                // ��ESC�˳�����������������
                if (m_msg.wParam == VK_ESCAPE)
                {
                    op = Menu;
                    break;
                }

            default:
                // ������Ϣ����
                break;
            }
        }

        // ���������߼�
        switch (op)
        {
        case Management::Menu:
            op = menu();
            break;
        case Management::Display:
            cout << "display" << endl;
            break;
        case Management::Add:
            cout << "add" << endl;
            break;
        case Management::Erase:
            cout << "erase" << endl;
            break;
        case Management::Modify:
            cout << "modify" << endl;
            break;
        case Management::Search:
            cout << "search" << endl;
            break;
        default:
            break;
        }

        if (op == Menu) {
            break; // ����ѭ���ص��˵�����
        }
    }
}


void Management::display()
{
	cout << "display" << endl;
}

void Management::add()
{
	cout << "add" << endl;
}

void Management::erase()
{
	cout << "erase" << endl;
}

void Management::modify()
{
	cout << "modify" << endl;
}

void Management::search()
{
	cout << "search" << endl;
}
